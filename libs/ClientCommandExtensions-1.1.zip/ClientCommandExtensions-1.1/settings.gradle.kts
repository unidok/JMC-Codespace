rootProject.name = "ClientCommandExtensions"

pluginManagement {
    repositories {
        maven {
            name = "Fabric"
            setUrl("https://maven.fabricmc.net/")
        }
        mavenCentral()
        gradlePluginPortal()
    }
}