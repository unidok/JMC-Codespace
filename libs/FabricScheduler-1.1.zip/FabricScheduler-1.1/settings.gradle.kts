rootProject.name = "FabricScheduler"

pluginManagement {
    repositories {
        maven {
            name = "Fabric"
            setUrl("https://maven.fabricmc.net/")
        }
        mavenCentral()
        gradlePluginPortal()
    }
}