package com.unidok.fabricscheduler.task

interface Delayed {
    var delay: Int
}